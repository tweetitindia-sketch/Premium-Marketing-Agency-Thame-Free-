/**
 * Tailwind CSS Plugin to Register Custom Font Families
 *
 * This plugin reads font definitions from `./src/config/fonts.json`,
 * generates CSS variables for each font, and creates corresponding utility classes.
 *
 * Example:
 * If fonts.json contains:
 * [
 *   {
 *     "name": "Inter",
 *     "cssVariable": "font-inter",
 *     "fallback": "sans-serif"
 *   }
 * ]
 *
 * It will generate:
 *   --font-inter: Inter, sans-serif;
 *   .font-inter {
 *     font-family: var(--font-inter);
 *   }
 */

import plugin from "tailwindcss/plugin";
import { fontFamily } from "../config/fonts.json";

/* ============================================================================
   FONT MAP PREPARATION
============================================================================ */

/**
 * Convert font definitions into a Tailwind-friendly map
 * key   → utility name
 * value → font-family stack
 */
const fontFamilies = Object.fromEntries(
  fontFamily.map((font) => [
    font.cssVariable?.replace("font-", "") || font.name.toLowerCase(),
    `${font.name}, ${font.fallback || "sans-serif"}`,
  ]),
);

/**
 * Generate CSS variables:
 * --font-inter: Inter, sans-serif;
 */
const fontVars = Object.fromEntries(
  Object.entries(fontFamilies).map(([key, value]) => [
    `--font-${key}`,
    value,
  ]),
);

/* ============================================================================
   TAILWIND PLUGIN EXPORT
============================================================================ */

module.exports = plugin.withOptions(
  () => {
    return ({ addBase, addUtilities }) => {
      /* --------------------------------------------------
         Register CSS Variables on :root
      -------------------------------------------------- */
      addBase({
        ":root": fontVars,
      });

      /* --------------------------------------------------
         Generate Font Utility Classes
         .font-inter { font-family: var(--font-inter); }
      -------------------------------------------------- */
      const fontUtilities = Object.fromEntries(
        Object.keys(fontFamilies).map((key) => [
          `.font-${key}`,
          { fontFamily: `var(--font-${key})` },
        ]),
      );

      addUtilities(fontUtilities);

      /* --------------------------------------------------
         PREMIUM SAFE EXTENSIONS (NON-BREAKING)
      -------------------------------------------------- */

      /**
       * Font smoothing helpers (optional use)
       */
      addUtilities({
        ".font-smooth": {
          "-webkit-font-smoothing": "antialiased",
          "-moz-osx-font-smoothing": "grayscale",
        },
        ".font-no-smooth": {
          "-webkit-font-smoothing": "auto",
          "-moz-osx-font-smoothing": "auto",
        },
      });

      /**
       * Numeric font rendering helpers (optional)
       */
      addUtilities({
        ".font-numeric-tabular": {
          "font-variant-numeric": "tabular-nums",
        },
        ".font-numeric-proportional": {
          "font-variant-numeric": "proportional-nums",
        },
      });
    };
  },
  () => ({
    /* --------------------------------------------------
       Optional Tailwind theme extension
       (Does NOT override anything)
    -------------------------------------------------- */
    theme: {
      extend: {
        fontFamily: fontFamilies,
      },
    },
  }),
);