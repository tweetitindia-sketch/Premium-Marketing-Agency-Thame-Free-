import { parseTomlToJson } from "@/lib/utils/tomlUtils";
import type { APIRoute } from "astro";

/**
 * Load global config (parsed from config.toml)
 * This controls robots.txt behavior dynamically
 */
const config = parseTomlToJson();

/**
 * robots.txt settings from config
 * example:
 * seo:
 *   robotsTxt:
 *     enable: true
 *     disallow:
 *       - /admin
 *       - /private
 */
const { enable, disallow } = config.seo.robotsTxt;

/**
 * Generate robots.txt content
 * @param sitemapURL Absolute sitemap URL
 */
const getRobotsTxt = (sitemapURL: URL) => `# Robots.txt file for controlling web crawler access
# Generated automatically by Astro

User-agent: *

# Allowed pages
Allow: /

# Disallowed pages
${disallow.map((item: string) => `Disallow: ${item}`).join("\n")}

# Sitemap location
Sitemap: ${sitemapURL.href}
`;

/**
 * Astro API Route
 * This will be available at: /robots.txt
 */
export const GET: APIRoute = ({ site }) => {
  const sitemapURL = new URL("sitemap-index.xml", site);

  /**
   * If robots.txt is enabled in config,
   * return generated robots.txt
   * Otherwise return 404 (as expected by crawlers)
   */
  return enable
    ? new Response(getRobotsTxt(sitemapURL), {
        headers: {
          "Content-Type": "text/plain; charset=utf-8",
        },
      })
    : new Response(null, { status: 404 });
};