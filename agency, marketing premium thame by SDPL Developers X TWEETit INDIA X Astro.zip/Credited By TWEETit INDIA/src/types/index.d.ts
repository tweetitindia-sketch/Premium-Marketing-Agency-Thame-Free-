// ============================================================================
// For Astro Font
// ============================================================================

type GlobalValues =
  | "inherit"
  | "initial"
  | "revert"
  | "revert-layer"
  | "unset";

interface Source {
  path?: string;
  preload?: boolean;
  css?: Record<string, string>;
  style:
    | "normal"
    | "italic"
    | "oblique"
    | `oblique ${number}deg`
    | GlobalValues
    | (string & {});
  weight?:
    | "normal"
    | "bold"
    | "lighter"
    | "bolder"
    | GlobalValues
    | 100
    | 200
    | 300
    | 400
    | 500
    | 600
    | 700
    | 800
    | 900
    | "100"
    | "200"
    | "300"
    | "400"
    | "500"
    | "600"
    | "700"
    | "800"
    | "900"
    | (string & {})
    | (number & {});
}

interface FontConfig {
  name: string;
  src: Source[];
  fetch?: boolean;
  verbose?: boolean;
  selector?: string;
  preload?: boolean;
  cacheDir?: string;
  basePath?: string;
  fallbackName?: string;
  googleFontsURL?: string;
  cssVariable?: string | boolean;
  fallback: "serif" | "sans-serif" | "monospace";
  display:
    | "auto"
    | "block"
    | "swap"
    | "fallback"
    | "optional"
    | (string & {});
}

// ============================================================================
// BUTTON
// ============================================================================

export type Button = {
  enable: boolean;
  label: string;
  url: string;
  rel?: string;
  target?: string;

  // Premium safe extensions
  icon?: string;
  variant?: "fill" | "outline" | "text" | "circle" | (string & {});
  size?: "sm" | "md" | "lg" | (string & {});
};

// ============================================================================
// SECTION
// ============================================================================

export type Section = {
  enable?: boolean;
  title?: string;
  excerpt?: string;
  date?: Date | string;
  author?: string;
  subtitle?: string;
  categories?: string[];
  description?: string;
  button?: Button;
  image?: string;
  limit?: false | number;

  // Premium optional extensions
  seoTitle?: string;
  seoDescription?: string;
  appearance?: "dark" | "light" | (string & {});
};

// ============================================================================
// SOCIAL LINKS
// ============================================================================

export type SocialLink = {
  enable: boolean;
  label: string;
  icon: string;
  url: string;

  // Optional enhancements
  rel?: string;
  target?: string;
  nofollow?: boolean;
};

// ============================================================================
// BADGE
// ============================================================================

export interface Badge {
  enable: boolean;
  label: string;
  color: "primary" | "success" | "danger" | "warning" | (string & {});
  type: "dot" | "text" | (string & {});
}

// ============================================================================
// NAVIGATION
// ============================================================================

export interface ChildNavigationLink {
  enable: boolean;
  name: string;
  url?: string;
  rel?: string;
  target?: string;
  hasChildren?: boolean;
  badge?: Badge;

  // Optional
  icon?: string;
  order?: number;

  children?: ChildNavigationLink[];
}

export interface NavigationLink extends ChildNavigationLink {
  enable: boolean;
  hasMegaMenu?: boolean;

  // Optional integrations
  testimonial?: Testimonial;
  services?: Service;

  menus?: NavigationLink[];
}

// ============================================================================
// OPTIONAL SUPPORT TYPES (SAFE PLACEHOLDERS)
// ============================================================================

export interface Testimonial {
  name?: string;
  role?: string;
  message?: string;
  image?: string;
}

export interface Service {
  title?: string;
  description?: string;
  icon?: string;
  url?: string;
}