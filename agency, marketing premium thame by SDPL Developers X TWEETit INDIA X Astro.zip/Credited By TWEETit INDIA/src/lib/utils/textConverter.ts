import slug_maker from "slugify";
import { marked } from "marked";

/**
 * Slugify text
 * ------------
 * Converts a string into a URL-friendly slug
 *
 * @param content Input text
 * @returns Slugified string
 */
export const slugifyyy = (content: string) => {
  if (!content) return "";

  return slug_maker(content, { lower: true });
};

/**
 * Markdownify
 * -----------
 * Converts markdown content to HTML
 * Supports inline or block parsing
 *
 * External link handling:
 * - getastrothemes → target="_blank" rel="noopener"
 * - Other external links → target="_blank" rel="noopener noreferrer nofollow"
 *
 * @param content   Markdown content
 * @param container Whether to parse as block or inline
 * @returns HTML string
 */
export const markdownify = (content: string, container?: boolean) => {
  if (!content) return "";

  const renderer = new marked.Renderer();

  /**
   * Custom link renderer
   */
  renderer.link = (link) => {
    const isExternal = link.href.startsWith("http");
    const targetAttrs = link.href.includes("getastrothemes")
      ? `target="_blank" rel="noopener"`
      : isExternal
        ? `target="_blank" rel="noopener noreferrer nofollow"`
        : "";

    return `<a href="${link.href}" ${targetAttrs}>${link.text}</a>`;
  };

  // Apply custom renderer
  marked.setOptions({
    renderer,
  });

  return container ? marked.parse(content) : marked.parseInline(content);
};

/**
 * Humanize text
 * -------------
 * Converts slug / snake_case / kebab-case into readable text
 *
 * @param content Input string
 * @returns Human-readable string
 */
export const humanize = (content: string) => {
  if (content)
    return content
      .replace(/^[\s_]+|[\s_]+$/g, "")
      .replace(/[_\s]+/g, " ")
      .replace(/[-\s]+/g, " ")
      .replace(/^[a-z]/, function (m) {
        return m.toUpperCase();
      });
};

/**
 * Titleify
 * --------
 * Converts text into Title Case
 *
 * @param content Input string
 * @returns Title-cased string
 */
export const titleify = (content: string) => {
  if (!content) {
    console.warn("No content provided to titleify " + content);
    return "";
  }

  const humanized = humanize(content) || "";
  return humanized
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

/**
 * Plainify
 * --------
 * Converts markdown to plain text
 * - Removes HTML tags
 * - Removes extra line breaks
 * - Decodes HTML entities
 *
 * @param content Markdown content
 * @returns Plain text string
 */
export const plainify = (content: string) => {
  const parseMarkdown: any = marked.parse(content);
  const filterBrackets = parseMarkdown.replace(/<\/?[^>]+(>|$)/gm, "");
  const filterSpaces = filterBrackets.replace(/[\r\n]\s*[\r\n]/gm, "");
  const stripHTML = htmlEntityDecoder(filterSpaces);
  return stripHTML;
};

/**
 * Decode HTML entities
 * --------------------
 * Used internally by plainify
 */
const htmlEntityDecoder = (htmlWithEntities: string) => {
  let entityList: { [key: string]: string } = {
    "&nbsp;": " ",
    "&lt;": "<",
    "&gt;": ">",
    "&amp;": "&",
    "&quot;": '"',
    "&#39;": "'",
  };

  let htmlWithoutEntities: string = htmlWithEntities.replace(
    /(&amp;|&lt;|&gt;|&quot;|&#39;)/g,
    (entity: string): string => {
      return entityList[entity];
    },
  );

  return htmlWithoutEntities;
};

/**
 * Convert to Uppercase
 *
 * @param content Input string
 * @returns Uppercase string
 */
export const toUpperCase = (content: string) => {
  if (!content) {
    console.warn("No content provided to toUppercase " + content);
    return "";
  }
  return content.toUpperCase();
};

/**
 * Convert to Lowercase
 *
 * @param content Input string
 * @returns Lowercase string
 */
export const toLowerCase = (content: string) => {
  if (!content) {
    console.warn("No content provided to toLowercase " + content);
    return "";
  }
  return content.toLowerCase();
};

/**
 * Convert to Sentence Case
 *
 * @param content Input string
 * @returns Sentence-cased string
 */
export const toSentenceCase = (content: string) => {
  if (!content) {
    console.warn("No content provided to toSentenceCase " + content);
    return "";
  }

  const lowercased = content.toLowerCase();
  return lowercased.charAt(0).toUpperCase() + lowercased.slice(1);
};

/**
 * Remove extra whitespace
 *
 * @param text Input string
 * @returns Cleaned string
 */
export function removeWhitespace(text: string) {
  return text.replace(/\s+/g, " ").trim();
}