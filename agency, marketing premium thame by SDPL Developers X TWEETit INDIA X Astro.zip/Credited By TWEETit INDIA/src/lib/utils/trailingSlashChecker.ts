import { parseTomlToJson } from "./tomlUtils";

const config = parseTomlToJson();

/**
 * Trailing Slash Checker
 * ----------------------
 * This utility ensures URL consistency based on the
 * `site.trailingSlash` option defined in `config.toml`.
 *
 * Behavior:
 * - If trailingSlash = true  → ensures trailing slash exists
 * - If trailingSlash = false → removes trailing slash if present
 *
 * Special Rules:
 * - Root path ("/") is never modified
 * - Anchor-only URLs ("/#section") are preserved
 * - URL fragments (#hash) are retained correctly
 *
 * @param url - The input URL path
 * @returns The normalized URL based on configuration
 */
const trailingSlashChecker = (url: string): string => {
  /**
   * Do not modify:
   * - Root path
   * - Root path with anchor
   */
  if (url === "/" || url.startsWith("/#")) {
    return url;
  }

  /**
   * Separate URL path and fragment (if exists)
   * Example:
   * "/about#team" → ["/about", "team"]
   */
  const [urlPath, fragment] = url.split("#");

  /**
   * Determine current and desired trailing slash state
   */
  const hasTrailingSlash = urlPath.endsWith("/");
  const shouldHaveTrailingSlash = config.site.trailingSlash;

  /**
   * Apply trailing slash rule
   */
  const adjustedPath = shouldHaveTrailingSlash
    ? hasTrailingSlash
      ? urlPath
      : `${urlPath}/`
    : hasTrailingSlash
      ? urlPath.slice(0, -1)
      : urlPath;

  /**
   * Reattach fragment if it exists
   */
  const fullURL = fragment ? `${adjustedPath}#${fragment}` : adjustedPath;

  return fullURL;
};

export default trailingSlashChecker;