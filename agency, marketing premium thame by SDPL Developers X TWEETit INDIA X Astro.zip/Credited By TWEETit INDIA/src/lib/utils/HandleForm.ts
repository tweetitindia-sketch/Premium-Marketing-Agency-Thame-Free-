// @ts-nocheck
import { markdownify } from "./textConverter";

/**
 * ----------------------------------------------------
 * FORM RESET
 * ----------------------------------------------------
 * - Clears all form inputs
 * - Removes validation success/error states
 * - Resets Preline select dropdowns
 */
export function formReset(form: HTMLFormElement) {
  form?.reset();

  const validationTags = form?.querySelectorAll(
    "[input-wrapper]:not(.hidden):not(.message).success, [input-wrapper]:not(.hidden):not(.message).error",
  );

  validationTags?.forEach((tag) => {
    tag.classList.remove("success", "error");
  });

  const selectTags = form?.querySelectorAll(
    "[input-wrapper]:not(.hidden) select[data-hs-select]",
  );

  selectTags?.forEach((tag) => {
    const selectElement = tag as HTMLSelectElement;
    const select = window.HSSelect.getInstance(tag);

    selectElement.selectedIndex = 0;

    if (select) {
      select.setValue("");
    }
  });
}

/**
 * ----------------------------------------------------
 * SELECT VALIDATION
 * ----------------------------------------------------
 * Adds success or error state to select wrapper
 */
export const validateSelectTag = (tag: HTMLSelectElement) => {
  const validationTag = tag.closest("[input-wrapper]");

  if (tag.value === "") {
    validationTag?.classList.add("error");
    validationTag?.classList.remove("success");
  } else {
    validationTag?.classList.contains("error") &&
      validationTag?.classList.add("success");
    validationTag?.classList.remove("error");
  }
};

/**
 * ----------------------------------------------------
 * FORM COMPLETENESS CHECK
 * ----------------------------------------------------
 * Ensures all required inputs/selects/textareas are filled
 */
export function isFormFilled(form: HTMLFormElement): boolean {
  const elements = form.querySelectorAll(
    "input[name], [input-wrapper]:not(.hidden) select[data-hs-select], textarea[name]",
  );

  type FormElement =
    | HTMLInputElement
    | HTMLSelectElement
    | HTMLTextAreaElement;

  for (let element of elements) {
    const elem = element as FormElement;

    if (elem.tagName === "SELECT" && elem.value === "") {
      return false;
    } else if (elem.hasAttribute("required") && elem.value === "") {
      return false;
    }
  }

  return true;
}

/**
 * ----------------------------------------------------
 * FORM MESSAGE HANDLER
 * ----------------------------------------------------
 * Displays success/error messages
 * Supports default & custom markdown messages
 */
export const setMessage = (
  message: string,
  success: boolean,
  disableSubmit = false,
  form: HTMLFormElement,
) => {
  const submitButton = form?.querySelector('button[type="submit"]');
  const messageType = success ? "success" : "error";
  const allMessages = form.querySelectorAll(".message");
  const messageElement = form.querySelector(`.message.${messageType}`);
  const msgEleText = messageElement?.querySelector(".prose-styles");
  const defaultMessage = msgEleText?.getAttribute("data-default");

  // Hide all messages except target
  allMessages.forEach((msg) => {
    if (msg !== messageElement) {
      msg.classList.add("hidden");
    }
  });

  // Load default message
  if (message === "default" && msgEleText && defaultMessage) {
    msgEleText.innerHTML = markdownify(defaultMessage, true) as string;
  }

  // Show selected message
  messageElement?.classList.remove("hidden");

  // Toggle submit button state
  if (disableSubmit) {
    submitButton?.setAttribute("disabled", "true");
  } else {
    submitButton?.removeAttribute("disabled");
  }

  // Custom message
  if (msgEleText && message !== "default") {
    msgEleText.innerHTML = markdownify(message, true) as string;
  }
};

/**
 * ----------------------------------------------------
 * MAIN FORM SUBMISSION (FormSubmit)
 * ----------------------------------------------------
 * - Uses AJAX submission
 * - Handles timeout & server errors
 */
export const formSubmit = async ({
  form,
  action,
}: {
  form: HTMLFormElement;
  action: string;
}) => {
  const data = Object.fromEntries(new FormData(form).entries());
  const controller = new AbortController();
  const signal = controller.signal;
  const timeout = 60000;

  // Convert to AJAX endpoint
  const ajaxAction = action.replace("formsubmit.co/", "formsubmit.co/ajax/");

  const timer = setTimeout(() => {
    controller.abort();
  }, timeout);

  fetch(ajaxAction, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(data),
    signal,
  })
    .then(async (response: any) => {
      const jsonResponse = await response.json();

      if (jsonResponse.success === "true") {
        setMessage("default", true, false, form);
        formReset(form);
      } else if (jsonResponse.success === "false") {
        setMessage(jsonResponse.message, false, false, form);
      }
    })
    .catch(async (error) => {
      if (error.name === "AbortError") {
        setMessage(
          "We couldn't reach the server. Trying alternative server.",
          false,
          false,
          form,
        );
      } else {
        setMessage(
          "Oops! There was a problem submitting your form.",
          false,
          false,
          form,
        );
      }
    })
    .finally(() => {
      clearTimeout(timer);
    });
};

/**
 * ----------------------------------------------------
 * FETCH WITH TIMEOUT
 * ----------------------------------------------------
 * Generic POST utility with abort support
 */
export const fetchWithTimeout = async (
  url: string,
  data: Record<string, FormDataEntryValue>,
  controller: AbortController,
  timeout: number,
) => {
  setTimeout(() => controller.abort(), timeout);

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(data),
    signal: controller.signal,
  });

  if (response.status !== 200) {
    throw new Error("Request failed with status code " + response.status);
  }
};

/**
 * ----------------------------------------------------
 * FORMSPREE FALLBACK SUBMISSION
 * ----------------------------------------------------
 */
export const formspreeSubmit = async (
  data: Record<string, FormDataEntryValue>,
  timeout: number,
  form: HTMLFormElement,
) => {
  try {
    await fetchWithTimeout(
      "https://formspree.io/f/xwpkvjaa",
      data,
      new AbortController(),
      timeout,
    );

    setMessage("default", true, false, form);
    formReset(form);
  } catch (error) {
    setMessage(
      error +
        "! Please use this mail - [folex-astro-theme@gmail.com](mailto:folex-astro-theme@gmail.com) to submit a ticket!",
      true,
      false,
      form,
    );
  }
};

/**
 * ----------------------------------------------------
 * NETLIFY FORM SUBMISSION
 * ----------------------------------------------------
 */
export const netlifySubmit = async (form: HTMLFormElement, action: string) => {
  const data = new URLSearchParams(new FormData(form) as any).toString();

  try {
    const response = await fetch(action, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: data,
    });

    if (response.ok) {
      setMessage("default", true, false, form);
      formReset(form);
    } else {
      throw new Error("Netlify form submission failed.");
    }
  } catch (error) {
    setMessage("Netlify submission error: " + error, false, false, form);
    throw error;
  }
};