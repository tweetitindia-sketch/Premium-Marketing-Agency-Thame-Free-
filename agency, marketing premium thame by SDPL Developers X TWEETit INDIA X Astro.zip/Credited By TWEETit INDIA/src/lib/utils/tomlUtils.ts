import fs from "fs";
import * as toml from "toml";

/**
 * Cached parsed TOML data
 * Used to avoid repeated file reads & parsing
 */
let cachedParsedToml: any = null;

/**
 * Remove empty keys from parsed TOML object
 * ------------------------------------------
 * - Removes keys with empty string values
 * - Recursively removes empty nested objects
 *
 * @param obj Parsed TOML object
 * @returns Cleaned object
 */
function removeEmptyKeys(obj: any) {
  Object.keys(obj).forEach((key) => {
    const value = obj[key];

    // Remove empty string values
    if (value === "") {
      delete obj[key];
    }
    // Recursively clean nested objects
    else if (typeof value === "object" && value !== null) {
      removeEmptyKeys(value);

      // Remove empty objects
      if (Object.keys(value).length === 0) {
        delete obj[key];
      }
    }
  });

  return obj;
}

/**
 * Parse TOML Configuration File
 * -----------------------------
 * - Reads `src/config/config.toml`
 * - Parses TOML to JSON
 * - Removes empty keys
 * - Caches the result for performance
 *
 * @returns Parsed TOML configuration object
 */
export function parseTomlToJson(): any {
  // Return cached config if already parsed
  if (cachedParsedToml) return cachedParsedToml;

  try {
    /**
     * Read TOML file from disk
     */
    const content = fs.readFileSync("src/config/config.toml", "utf8");

    if (!content) {
      throw new Error(`File not found: src/config/config.toml`);
    }

    /**
     * Parse TOML → JS Object
     */
    const tomlContent = toml.parse(content);

    /**
     * Normalize object (deep clone)
     * Ensures no unexpected references
     */
    let parsedToml = JSON.stringify(tomlContent, null, 2);
    parsedToml = JSON.parse(parsedToml);

    /**
     * Remove empty values
     */
    parsedToml = removeEmptyKeys(parsedToml);

    /**
     * Cache parsed config
     */
    cachedParsedToml = parsedToml;

    return parsedToml;
  } catch (error) {
    console.error(`Error parsing TOML file: ${error}`);
    throw error;
  }
}

/**
 * Vite Plugin: Reload on TOML Change
 * ---------------------------------
 * Automatically triggers full reload
 * when any `.toml` file is modified
 *
 * Used in development mode
 */
export function reloadOnTomlChange() {
  return {
    name: "reload-on-toml-change",
    handleHotUpdate({ file, server }: any) {
      if (file.endsWith(".toml")) {
        console.log("TOML file changed, triggering reload...");
        server.ws.send({ type: "full-reload" });
      }
    },
  };
}