import { parseTomlToJson } from "./tomlUtils";
import languagesJSON from "../../config/language.json";
import trailingSlashChecker from "./trailingSlashChecker";
import path from "node:path";

/**
 * Load multilingual configuration
 */
const config = parseTomlToJson();

let {
  enable: multilingualEnable,
  showDefaultLangInUrl,
  defaultLanguage,
  disableLanguages,
} = config.settings.multilingual;

/**
 * Get enabled locales based on configuration
 */
export const getEnabledLocales = (
  languagesJSON: any[],
  multilingualEnable: any,
  disableLanguages = [],
  defaultLang = "en",
) => {
  const supported = languagesJSON.map(
    (lang: { languageCode: any }) => lang.languageCode,
  );

  const disabled = multilingualEnable
    ? disableLanguages
    : supported.filter((lang: string) => lang !== defaultLang);

  return supported.filter((lang: any) => !disabled.includes(lang));
};

/**
 * Enabled languages list
 */
export const enabledLanguages = getEnabledLocales(
  languagesJSON,
  multilingualEnable,
  disableLanguages,
  defaultLanguage,
);

/**
 * Translation loader with caching
 * -------------------------------
 * Loads menu + dictionary JSON per language
 * Falls back to default language if disabled or missing
 */
const translationCache: Record<string, any> = {};

export const useTranslations = async (lang: string): Promise<Function> => {
  const { defaultLanguage, disableLanguages } = config.settings.multilingual;

  /**
   * Resolve language (fallback if disabled)
   */
  const resolvedLang = disableLanguages?.includes(lang)
    ? defaultLanguage
    : lang;

  /**
   * Return from cache if available
   */
  if (translationCache[resolvedLang]) {
    return translationCache[resolvedLang];
  }

  /**
   * Find language configuration
   */
  const language =
    languagesJSON.find((l) => l.languageCode === resolvedLang) ||
    languagesJSON.find((l) => l.languageCode === defaultLanguage);

  if (!language) {
    throw new Error("Default language configuration not found");
  }

  const contentDir = language.contentDir;
  let menu, dictionary;

  /**
   * Load translations dynamically
   */
  try {
    menu = await import(`../../../src/config/menu.${lang}.json`);
    dictionary = await import(`../../../src/i18n/${lang}.json`);
  } catch (error) {
    /**
     * Fallback to default language
     */
    menu = await import(`../../../src/config/menu.${defaultLanguage}.json`);
    dictionary = await import(`../../../src/i18n/${defaultLanguage}.json`);
  }

  /**
   * Combine translation sources
   */
  const translations = {
    ...menu,
    ...dictionary,
    contentDir,
  };

  /**
   * Dot-notation translation function
   */
  type NestedObject = Record<string, any>;

  type DotNotationKeys<T> = T extends NestedObject
    ? {
        [K in keyof T & string]: T[K] extends NestedObject
          ? `${K}` | `${K}.${DotNotationKeys<T[K]>}`
          : `${K}`;
      }[keyof T & string]
    : never;

  const t = <T extends NestedObject>(key: DotNotationKeys<T>): string | any => {
    const keys = key.split(".");
    let value: any = translations;

    for (const k of keys) {
      if (value && typeof value === "object" && k in value) {
        value = value[k];
      } else {
        return "Not Found";
      }
    }

    return value;
  };

  /**
   * Cache translations
   */
  translationCache[resolvedLang] = Object.assign(t, translations);

  return translationCache[resolvedLang];
};

/**
 * Supported languages (cached)
 */
let cachedLanguages: Array<any> | null = null;

export const getSupportedLanguages = (): Array<any> => {
  if (cachedLanguages) {
    return cachedLanguages;
  }

  const supportedLanguages = [...languagesJSON.map((lang) => lang)];

  let disabledLanguages = config.settings.multilingual.enable
    ? config.settings.multilingual.disableLanguages
    : supportedLanguages
        .map((lang) => lang.languageCode !== "en" && lang.languageCode)
        .filter(Boolean);

  cachedLanguages = disabledLanguages
    ? supportedLanguages.filter(
        (lang) => !disabledLanguages.includes(lang.languageCode),
      )
    : supportedLanguages;

  return cachedLanguages;
};

/**
 * Export supported languages directly
 */
export const supportedLanguages = getSupportedLanguages();

/**
 * Generate static paths for each language
 */
export function generatePaths(): Array<{
  params: { lang: string | undefined };
}> {
  const supportedLanguages = getSupportedLanguages();

  return supportedLanguages.map((lang) => ({
    params: {
      lang:
        lang.languageCode === defaultLanguage && !showDefaultLangInUrl
          ? undefined
          : lang.languageCode,
    },
  }));
}

/**
 * Generate localized URL
 * ----------------------
 * Handles:
 * - Internal vs external URLs
 * - mailto / tel
 * - absolute & relative URLs
 * - language prefixes
 * - trailing slashes
 * - anchors
 */
export const getLocaleUrlCTM = (
  url: string,
  providedLang: string | undefined,
  prependValue?: string,
): string => {
  const language = providedLang || defaultLanguage;
  const languageCodes = languagesJSON.map((language) => language.languageCode);
  const languageDirectories = new Set(
    languagesJSON.map((language) => language.contentDir),
  );

  /**
   * Check if URL is external
   */
  function checkIsExternal(url: string) {
    try {
      const parsedUrl = new URL(url, config.site.baseUrl);
      const baseUrl = new URL(config.site.baseUrl);

      if (!parsedUrl.protocol.startsWith("http")) {
        return false;
      }

      const isSameOrigin = parsedUrl.origin === baseUrl.origin;
      const isLocalhost =
        parsedUrl.hostname === "localhost" ||
        parsedUrl.hostname === "127.0.0.1";

      return !(isSameOrigin || isLocalhost);
    } catch (error) {
      return false;
    }
  }

  let updatedUrl = url;
  let isExternalUrl = checkIsExternal(url);

  /**
   * Skip external URLs
   */
  if (isExternalUrl) return url;

  /**
   * Skip mailto / tel
   */
  if (url.startsWith("mailto:") || url.startsWith("tel:")) return url;

  const isAbsoluteUrl = url.startsWith("http://") || url.startsWith("https://");
  let hash;

  /**
   * Handle absolute URLs
   */
  if (isAbsoluteUrl) {
    updatedUrl = new URL(url).pathname;

    if (url.includes("#")) {
      hash = url.split("#")[1];
    }
  }

  /**
   * Remove existing language directory
   */
  for (const langDir of languageDirectories) {
    if (updatedUrl.startsWith(`${langDir}/`)) {
      updatedUrl = updatedUrl.replace(`${langDir}/`, "/");
      break;
    }
  }

  /**
   * Prepend optional path segment
   */
  if (prependValue) {
    if (!prependValue.startsWith("/")) {
      updatedUrl = path.posix.join("/" + prependValue, updatedUrl);
    } else {
      updatedUrl = path.posix.join(prependValue, updatedUrl);
    }
  }

  const isDefaultLanguage = language === defaultLanguage;

  /**
   * Remove language from URL
   */
  const getUrlWithoutLang = (u: string): string | undefined => {
    const segments = u.split("/");
    const lang = languageCodes.find((item) => segments.includes(item));

    const urlWithoutLang = u.replace(`/${lang}`, "");

    if (urlWithoutLang === "") return "/";

    return urlWithoutLang;
  };

  const shouldShowDefaultLang = isDefaultLanguage && showDefaultLangInUrl;
  const shouldOmitDefaultLang = isDefaultLanguage && !showDefaultLangInUrl;

  /**
   * Handle root URL
   */
  if (updatedUrl === "/" || updatedUrl === "") {
    updatedUrl = `/${defaultLanguage || ""}`;
  }

  /**
   * Determine language prefix
   */
  const prependLanguage = shouldOmitDefaultLang
    ? ""
    : `/${shouldShowDefaultLang ? defaultLanguage : language}`;

  /**
   * Combine URL parts
   */
  updatedUrl = path.posix.join(
    prependLanguage,
    getUrlWithoutLang(updatedUrl) as string,
  );

  /**
   * Apply trailing slash rules
   */
  updatedUrl = trailingSlashChecker(updatedUrl);

  /**
   * Reconstruct absolute URL
   */
  if (isAbsoluteUrl) {
    updatedUrl = new URL(url).origin + updatedUrl;

    if (hash) {
      updatedUrl = `${updatedUrl}#${hash}`;
    }
  }

  return updatedUrl;
};