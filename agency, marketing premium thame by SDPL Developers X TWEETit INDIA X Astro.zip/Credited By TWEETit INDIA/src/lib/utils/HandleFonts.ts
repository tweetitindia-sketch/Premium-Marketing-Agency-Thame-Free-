import type { AstroConfig } from "astro";
import { fontProviders } from "astro/config";

/* =========================================================
   TYPES
========================================================= */

interface FontSrc {
  weight: string;
  style?: string;
  path?: string;
}

interface InputFontConfig {
  name: string;
  src: FontSrc[];
  provider: string;
  cssVariable: string;
  display?: "auto" | "block" | "swap" | "fallback" | "optional";
  fallback?: string;
  subsets?: string[];
  unicodeRange?: string[];
  optimizedFallbacks?: boolean;
}

interface InputConfig {
  fontFamily: InputFontConfig[];
}

type FontProvider =
  | ReturnType<typeof fontProviders.google>
  | ReturnType<typeof fontProviders.fontsource>
  | ReturnType<typeof fontProviders.bunny>
  | ReturnType<typeof fontProviders.fontshare>
  | ReturnType<typeof fontProviders.adobe>
  | "local";

interface BaseAstroFontConfig {
  provider: FontProvider;
  name: string;
  cssVariable: string;
  display?: "auto" | "block" | "swap" | "fallback" | "optional";
  fallbacks?: string[];
  optimizedFallbacks?: boolean;
}

interface RemoteAstroFontConfig extends BaseAstroFontConfig {
  provider: Exclude<FontProvider, "local">;
  weights?: (string | number)[];
  styles?: ("normal" | "italic" | "oblique")[];
  subsets?: string[];
  unicodeRange?: string[];
}

interface LocalAstroFontConfig extends BaseAstroFontConfig {
  provider: "local";
  variants: Array<{
    weight: string | number;
    style: "normal" | "italic" | "oblique";
    src: string[];
    display?: "auto" | "block" | "swap" | "fallback" | "optional";
  }>;
}

type AstroFontConfig = RemoteAstroFontConfig | LocalAstroFontConfig;

/* =========================================================
   ERRORS
========================================================= */

class FontConversionError extends Error {
  constructor(message: string, public font?: InputFontConfig) {
    super(message);
    this.name = "FontConversionError";
  }
}

/* =========================================================
   MAIN EXPORT
========================================================= */

export function convertToAstroFontConfig(
  config: InputConfig,
): AstroFontConfig[] {
  if (!config.fontFamily || !Array.isArray(config.fontFamily)) {
    throw new FontConversionError("fontFamily must be an array");
  }

  return config.fontFamily.map((font) => convertSingleFont(font));
}

/* =========================================================
   SINGLE FONT CONVERTER
========================================================= */

function convertSingleFont(font: InputFontConfig): AstroFontConfig {
  if (!font.name) throw new FontConversionError("Font name missing", font);
  if (!font.cssVariable)
    throw new FontConversionError("cssVariable missing", font);
  if (!font.provider)
    throw new FontConversionError("Font provider missing", font);

  const cssVariable = normalizeCssVariable(font.cssVariable);
  const isLocal = font.provider.toLowerCase() === "local";

  return isLocal
    ? createLocalFontConfig(font, cssVariable)
    : createRemoteFontConfig(font, cssVariable);
}

/* =========================================================
   LOCAL FONT
========================================================= */

function createLocalFontConfig(
  font: InputFontConfig,
  cssVariable: string,
): LocalAstroFontConfig {
  const variants = font.src.map((src) => {
    if (!src.path) {
      throw new FontConversionError("Local font path missing", font);
    }

    return {
      weight: convertWeightToNumber(src.weight) || src.weight,
      style: normalizeStyle(src.style),
      src: [src.path],
      display: font.display,
    };
  });

  return {
    provider: "local",
    name: font.name,
    cssVariable,
    variants,
    fallbacks: font.fallback ? [font.fallback] : undefined,
    optimizedFallbacks: font.optimizedFallbacks,
  };
}

/* =========================================================
   REMOTE FONT
========================================================= */

function createRemoteFontConfig(
  font: InputFontConfig,
  cssVariable: string,
): RemoteAstroFontConfig {
  const provider = getProvider(font.provider);
  const weights = extractWeights(font.src);
  const styles = extractStyles(font.src);

  return {
    provider,
    name: font.name,
    cssVariable,
    weights,
    styles,
    display: font.display,
    fallbacks: font.fallback ? [font.fallback] : undefined,
    subsets: font.subsets,
    unicodeRange: font.unicodeRange,
    optimizedFallbacks: font.optimizedFallbacks,
  };
}

/* =========================================================
   HELPERS
========================================================= */

function normalizeCssVariable(cssVar: string): string {
  return cssVar.startsWith("--") ? cssVar : `--${cssVar}`;
}

function normalizeStyle(
  style?: string,
): "normal" | "italic" | "oblique" {
  const s = (style || "normal").toLowerCase();
  return s === "italic" || s === "oblique" ? s : "normal";
}

function getProvider(provider: string): Exclude<FontProvider, "local"> {
  const key = provider.toLowerCase();

  switch (key) {
    case "google":
      return fontProviders.google();
    case "fontsource":
      return fontProviders.fontsource();
    case "bunny":
      return fontProviders.bunny();
    case "fontshare":
      return fontProviders.fontshare();
    case "adobe":
      return fontProviders.adobe({ id: process.env.ADOBE_ID || "" });
    default:
      console.warn("Unknown provider, fallback to Google:", provider);
      return fontProviders.google();
  }
}

function extractWeights(src: FontSrc[]): (string | number)[] {
  const set = new Set<string | number>();
  src.forEach((s) => {
    set.add(convertWeightToNumber(s.weight) || s.weight);
  });
  return Array.from(set);
}

function extractStyles(
  src: FontSrc[],
): ("normal" | "italic" | "oblique")[] {
  const set = new Set<"normal" | "italic" | "oblique">();
  src.forEach((s) => set.add(normalizeStyle(s.style)));
  return Array.from(set);
}

function convertWeightToNumber(weight: string): number | undefined {
  const map: Record<string, number> = {
    thin: 100,
    extralight: 200,
    light: 300,
    normal: 400,
    regular: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
    extrabold: 800,
    black: 900,
  };

  const lower = weight.toLowerCase();
  if (map[lower]) return map[lower];

  const num = parseInt(weight);
  return isNaN(num) ? undefined : num;
}

/* =========================================================
   ASTRO CONFIG HELPER
========================================================= */

export function createAstroConfigWithFonts(
  input: InputConfig,
  extra?: Partial<AstroConfig>,
): AstroConfig {
  const fonts = convertToAstroFontConfig(input);

  return {
    ...extra,
    experimental: {
      ...extra?.experimental,
      fonts,
    },
  };
}