/**
 * Override Objects Utility
 * ------------------------
 * Deeply overrides properties of a target object
 * using values from a source object.
 *
 * Rules:
 * - Target object is cloned first (immutable behavior)
 * - Nested objects are merged recursively
 * - Arrays are NOT merged (they are overwritten)
 * - Primitive values are overwritten directly
 *
 * NOTE:
 * Logic and behavior are preserved exactly.
 *
 * @param target Base object
 * @param source Override object
 * @returns New merged object
 */
export default function overrideObjects(target: any, source: any): any {
  /**
   * Create a deep clone of the target
   * to avoid mutating original object
   */
  const result = structuredClone(target);

  /**
   * Iterate through all keys in source object
   */
  for (const key in source) {
    /**
     * If both source and target values are objects
     * (and not arrays), merge recursively
     */
    if (
      source[key] &&
      typeof source[key] === "object" &&
      !Array.isArray(source[key]) && // Ensure it's not an array
      result[key] &&
      typeof result[key] === "object"
    ) {
      result[key] = overrideObjects(result[key], source[key]);
    } else {
      /**
       * Otherwise overwrite or add the value
       */
      result[key] = source[key];
    }
  }

  return result;
}