/**
 * JSON-LD Generator
 * -----------------
 * Generates Schema.org compliant JSON-LD data
 * for better SEO and search engine understanding.
 *
 * Supported search engines:
 * - Google
 * - Bing
 * - DuckDuckGo
 *
 * NOTE:
 * All logic and output structure are preserved exactly.
 */

import { absoluteUrl } from "./absoluteUrl";
import { getLocaleUrlCTM } from "./i18nUtils";
import removeEmptyKeys from "./removeEmptyKeys";
import trailingSlashChecker from "./trailingSlashChecker";
import social from "@/config/social.json";

/**
 * JSON-LD Props Definition
 */
export type JSONLDProps = {
  canonical?: string; // Canonical URL of the page
  title?: string; // Page title
  description?: string; // Page description
  image?: string; // Image URL (blogs, case studies, etc.)
  categories?: string[]; // Categories or tags
  author?: string; // Author name
  pageType?: string; // Page type (WebPage, Article, etc.)

  [key: string]: any;
};

/**
 * JSON-LD Generator Function
 *
 * @param content Page content data
 * @param Astro   Astro global object
 * @returns Clean JSON-LD object
 */
export default function JsonLdGenerator(content: JSONLDProps, Astro: any) {
  let {
    canonical = "/",
    title = "",
    description = "",
    image = "",
    pageType = "",
    lang = "en", // Default language
    alternateLangs = [], // Alternate language URLs
    config,
  } = content || {};

  /**
   * Base JSON-LD structure
   */
  let jsonLdData: Record<string, any> = {
    "@context": "https://schema.org",
  };

  /**
   * Generate schema based on page type
   */
  switch (pageType) {
    default:
      jsonLdData["@type"] = "WebPage";
      jsonLdData.name = title;
      jsonLdData.description = description;
      jsonLdData.image = image;
      jsonLdData.url = canonical;

      if (lang) {
        jsonLdData.inLanguage = lang;
      }
  }

  /**
   * Add site metadata
   */
  const siteTitle =
    config.site.title +
    (config.site.tagline &&
      (config.site.taglineSeparator || " - ") + config.site.tagline);

  jsonLdData["isPartOf"] = {
    "@type": "WebSite",
    name: siteTitle,
    description: config.site.description,
    url: trailingSlashChecker(Astro.url.origin),
  };

  /**
   * Add alternate languages
   */
  if (alternateLangs.length > 0) {
    jsonLdData.alternateLanguage = alternateLangs
      .filter((alt: any) => Astro.currentLocale !== alt.languageCode)
      .map((alt: any) => ({
        "@type": "WebPage",
        url: getLocaleUrlCTM(canonical, alt.languageCode),
        inLanguage: alt.languageCode,
      }));
  }

  /**
   * Publisher information
   */
  jsonLdData.publisher = {
    "@type": "Organization",
    name: config.seo.author,
    url: trailingSlashChecker(Astro.url.origin),
    sameAs: social.main.filter((item) => item.enable).map((item) => item.url),
    logo: {
      "@type": "ImageObject",
      url: absoluteUrl(config.site.logo, Astro),
    },
  };

  /**
   * Clean empty or undefined keys
   */
  return removeEmptyKeys(jsonLdData);
}