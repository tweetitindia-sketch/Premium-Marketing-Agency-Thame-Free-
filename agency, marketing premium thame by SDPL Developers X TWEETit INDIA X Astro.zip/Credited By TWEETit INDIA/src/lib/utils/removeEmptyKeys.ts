/**
 * Remove Empty Keys Utility
 * -------------------------
 * Recursively removes empty values from an object.
 *
 * Rules (as-is, unchanged):
 * - Removes keys if value is:
 *   - Empty string ("")
 *   - Empty array ([])
 *   - Empty object ({})
 * - Recursively checks nested objects
 * - Deletes parent key if nested object becomes empty
 *
 * NOTE:
 * All conditions are preserved exactly as provided.
 * No logic or behavior has been modified.
 *
 * @param obj Input object to clean
 * @returns Cleaned object
 */
export default function removeEmptyKeys(obj: any) {
  Object.keys(obj).forEach((key) => {
    const value = obj[key];

    /**
     * Remove key if value is:
     * - Empty string
     * - Empty array
     * - Empty object (based on existing condition logic)
     */
    if (
      value === "" ||
      (Array.isArray(value) && value.length === 0) ||
      (typeof value === "object" &&
        value !== null &&
        typeof value === "undefined" &&
        value &&
        Object.keys(value).length === 0)
    ) {
      delete obj[key];
    }
    /**
     * Recursively process nested objects
     */
    else if (
      typeof value === "object" &&
      typeof value !== "undefined" &&
      value !== null &&
      value !== undefined
    ) {
      removeEmptyKeys(value);

      /**
       * Remove key if nested object becomes empty
       */
      if (Object.keys(value).length === 0) {
        delete obj[key];
      }
    }
  });

  return obj;
}