/**
 * Unique ID Generator
 * -------------------
 * This utility generates a short, deterministic unique ID
 * from a given string.
 *
 * Features:
 * - Uses in-memory caching for repeat inputs
 * - Randomizes word order before hashing
 * - Generates compact base36 IDs
 * - Same input → same output (via cache)
 */

const cache = new Map<string, string>();

export default function uniqueIdGenerator(str: string): string {
  /**
   * Check if the result for this input
   * already exists in cache
   */
  if (cache.has(str)) {
    return cache.get(str)!;
  }

  /**
   * Randomize the sentence
   * (used only once per unique string)
   */
  const words = str.split(" ");
  for (let i = words.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [words[i], words[j]] = [words[j], words[i]];
  }

  const randomizedSentence = words.join(" ");

  /**
   * Generate a short hash
   * Using a simple rolling checksum
   * Limited to 6 digits for compactness
   */
  let hash = 0;
  for (let i = 0; i < randomizedSentence.length; i++) {
    hash = (hash * 31 + randomizedSentence.charCodeAt(i)) % 1000000;
  }

  /**
   * Convert hash to base36
   * (shorter, URL-safe)
   */
  const uniqueId = hash.toString(36);

  /**
   * Cache the result for future calls
   */
  cache.set(str, uniqueId);

  /**
   * Return only the unique ID
   */
  return uniqueId;
}