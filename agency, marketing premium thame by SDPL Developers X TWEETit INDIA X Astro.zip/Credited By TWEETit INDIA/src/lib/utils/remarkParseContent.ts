// @ts-nocheck
import { visit } from "unist-util-visit";
import type { Root, Heading, Image, PhrasingContent } from "mdast";

/**
 * Extract plain text from a heading node
 * --------------------------------------
 * Supports nested nodes like:
 * - **bold**
 * - *italic*
 * - inline elements
 *
 * @param node Markdown phrasing content
 * @returns Extracted text
 */
function extractTextFromNode(node: PhrasingContent): string {
  if (node.type === "text") {
    return node.value;
  }

  if ("children" in node) {
    return (node.children as PhrasingContent[])
      .map(extractTextFromNode)
      .join("");
  }

  return "";
}

/**
 * Remark Plugin: Parse Content
 * ----------------------------
 * Features:
 * 1. Add custom classes to markdown headings
 *    Syntax:
 *    ## Heading Text [.class .another-class]
 *
 * 2. Automatically add:
 *    loading="lazy"
 *    to all markdown images
 */
export default function remarkParseContent() {
  return (tree: Root) => {
    /**
     * Process heading nodes
     */
    visit(tree, "heading", (node: Heading) => {
      if (!node.children || node.children.length === 0) return;

      /**
       * Extract full heading text
       * (even if wrapped in bold / italic)
       */
      const headingText = node.children
        .map(extractTextFromNode)
        .join("");

      /**
       * Match class syntax inside square brackets
       * Example:
       * [.class-one .class-two]
       */
      const classRegex = /\[([^\]]+)\]/g;
      const classes: string[] = [];
      let match;

      /**
       * Extract class names
       */
      while ((match = classRegex.exec(headingText)) !== null) {
        const classList = match[1]
          .split(/\s+/)
          .filter((cls) => cls.startsWith("."));

        classes.push(...classList.map((cls) => cls.slice(1)));
      }

      /**
       * Remove class notation from visible heading text
       */
      node.children = node.children.map((child) => {
        if (child.type === "text") {
          return {
            ...child,
            value: child.value.replace(classRegex, "").trim(),
          };
        }

        return child;
      });

      /**
       * Attach extracted classes to heading element
       */
      if (classes.length > 0) {
        node.data = node.data || {};
        node.data.hProperties = node.data.hProperties || {};

        node.data.hProperties.class = [
          ...(node.data.hProperties.class
            ? node.data.hProperties.class.split(" ")
            : []),
          ...classes,
        ].join(" ");
      }
    });

    /**
     * Process image nodes
     * -------------------
     * Add loading="lazy" attribute
     */
    visit(tree, "image", (node: Image) => {
      node.data = node.data || {};
      node.data.hProperties = node.data.hProperties || {};
      node.data.hProperties.loading = "lazy";
    });
  };
}