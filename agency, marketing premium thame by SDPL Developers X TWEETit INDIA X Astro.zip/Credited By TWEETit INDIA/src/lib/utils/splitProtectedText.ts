/**
 * Split Protected Text
 * --------------------
 * This utility splits text on "/" while:
 * - Protecting URLs from being broken
 * - Supporting dynamic year placeholders
 *
 * Common use cases:
 * - Footer text
 * - Copyright strings
 * - Navigation labels
 *
 * Example:
 * "Privacy / Terms / https://example.com"
 *
 * @param text     Input text to split
 * @param options  Optional configuration
 * @returns Array of split strings
 */
export function splitProtectedText(
  text: string,
  options?: { yearPlaceholder?: string },
): string[] {
  /**
   * Default year placeholder if not provided
   * Example placeholders supported:
   * {{year}}, {{ year }}, {{  year  }}
   */
  const yearPlaceholder = options?.yearPlaceholder || "{{ year }}";
  const currentYear = new Date().getFullYear().toString();

  /**
   * STEP 1: Protect URLs
   * --------------------
   * Replace URLs with placeholders to prevent
   * accidental splitting
   */
  const urlRegex = /https?:\/\/[^\s)]+/g;
  const urlPlaceholders: Record<string, string> = {};

  const protectedText = text.replace(urlRegex, (url, index) => {
    const placeholder = `__URL${index}__`;
    urlPlaceholders[placeholder] = url;
    return placeholder;
  });

  /**
   * STEP 2: Split on slashes
   * -----------------------
   * Supports optional spaces around "/"
   */
  let parts = protectedText.split(/\s*\/\s*/);

  /**
   * STEP 3: Restore URLs
   * -------------------
   * Replace placeholders back with original URLs
   */
  parts = parts.map((part) =>
    part.replace(/__URL\d+__/g, (match) => urlPlaceholders[match] || match),
  );

  /**
   * STEP 4: Replace year placeholder
   * --------------------------------
   * Supports flexible spacing inside placeholders
   */
  const yearRegex = new RegExp(
    yearPlaceholder.replace(/\s+/g, "\\s*").replace(/[{}]/g, "\\$&"),
    "g",
  );

  parts = parts.map((part) => part.replace(yearRegex, currentYear));

  return parts;
}