import { parseTomlToJson } from "@/lib/utils/tomlUtils";
import { defineCollection, z } from "astro:content";
import { button, sectionsSchema } from "./sections.schema";
import { glob } from "astro/loaders";

const config = parseTomlToJson();
const portfolioFolder = config.settings.portfolioFolder || "portfolio";
const servicesFolder = config.settings.servicesFolder || "services";

// Universal Page Schema
export const page = z.object({
  title: z.string(),

  author: z.string().optional(),

  categories: z.array(z.string()).default(["others"]).optional(),
  tags: z.array(z.string()).default(["others"]).optional(),

  date: z.date().optional(),

  description: z.string().optional(),
  image: z.string().optional(),

  draft: z.boolean().optional(),

  button: button.optional(),

  // ======================
  // SEO – PREMIUM DEFAULTS
  // ======================

  metaTitle: z
    .string()
    .optional()
    .default("TWEETit INDIA – Private IT Initiative & Technology Research"),

  metaDescription: z
    .string()
    .optional()
    .default(
      "TWEETit INDIA is a private IT initiative under SHUBHAM DONGARE PRIVATE LIMITED, focused on in-house systems, technology research, and internal digital innovation. We collaborate with skilled developers and IT professionals for long-term growth.",
    ),

  robots: z
    .string()
    .optional()
    .default(
      "index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1",
    ),

  canonical: z
    .string()
    .optional()
    .default("https://www.tweetitindia.com/"),

  keywords: z
    .array(z.string())
    .optional()
    .default([
      "private IT company India",
      "in-house software development",
      "technology research company",
      "IT initiative India",
      "developer opportunities India",
      "SHUBHAM DONGARE PRIVATE LIMITED",
      "DONAGRES INDUSTRIES",
      "TWEETit INDIA",
    ]),

  excludeFromSitemap: z.boolean().optional().default(false),

  excludeFromCollection: z.boolean().optional(),

  customSlug: z.string().optional(),

  disableTagline: z.boolean().optional(),

  // ======================
  // Sections (unchanged)
  // ======================
  ...sectionsSchema,
});

// Pages collection schema
const pagesCollection = defineCollection({
  schema: page,
});

// Service collection schema
const serviceCollection = defineCollection({
  schema: page.merge(
    z.object({
      icon: z.string().optional(),
    }),
  ),
});

// Portfolio Collection
const portfolioCollection = defineCollection({
  loader: glob({ base: "./src/content/portfolio", pattern: "**/*.{md,mdx}" }),
  schema: page.merge(
    z.object({
      images: z.array(z.string()).min(1).optional(),

      options: z
        .object({
          layout: z.enum(["masonry", "grid", "full-width", "slider"]),
          appearance: z.enum(["dark", "light"]).optional(),
          limit: z.union([z.number().int(), z.literal(false)]).optional(),
        })
        .optional(),

      information: z
        .array(
          z.object({
            label: z.string(),
            value: z.string(),
          }),
        )
        .optional(),
    }),
  ),
});

// Export collections
export const collections = {
  [servicesFolder]: serviceCollection,
  services: serviceCollection,

  [portfolioFolder]: portfolioCollection,
  portfolio: portfolioCollection,

  pages: pagesCollection,

  sections: defineCollection({}),
  homepage: defineCollection({}),
};